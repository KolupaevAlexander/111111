﻿using System;
using NUnit.Framework;
using HeroVsMonster.Classes;

namespace HeroVsMonster.Tests
{
    class HeroTests
    {
        Hero Vasya;
        Hero Noob;        

        [SetUp]
        public void Setup()
        {
            Vasya = new Hero("Вася Пупкин", 200, 15);
            Noob = new Hero("Noob", 3, 1);
        }

        [Test]
        public void Vasya_Has_Correct_Name()
        {
            string Expected = "Вася Пупкин";
            string Actual = Vasya.Name;
            Assert.AreEqual(Expected, Actual);
        }

        [Test]
        public void Vasya_Has_Correct_Damage()
        {
            int Expected = 15;
            int Actual = Vasya.Damage;
            Assert.AreEqual(Expected, Actual);
        }

        [Test]
        public void Vasya_Has_Correct_MaxHp()
        {
            int Expected = 200;
            int Actual = Vasya.MaximumHealth;
            Assert.AreEqual(Expected, Actual);
        }

        [Test]
        public void Vasya_Get_1_Damage()
        {
            Vasya.GetDamage(1);
            int ExpectedHp = 199;
            int ActualHp = Vasya.Health;
            Assert.AreEqual(ExpectedHp, ActualHp);
        }

        [Test]
        public void Vasya_Get_105_Damage()
        {
            Vasya.GetDamage(105);
            int ExpectedHp = 95;
            int ActualHp = Vasya.Health;
            Assert.AreEqual(ExpectedHp, ActualHp);
        }

        [Test]
        public void Vasya_Get_9999_Damage()
        {
            Vasya.GetDamage(9999);
            int ExpectedHp = 0;
            int ActualHp = Vasya.Health;
            Assert.AreEqual(ExpectedHp, ActualHp);
        }

        [Test]
        public void Vasya_Get_9999_Damage_And_Die()
        {
            Vasya.GetDamage(9999);
            Assert.IsTrue(Vasya.IsDead);
        }

        [Test]
        public void Vasya_Get_FullHp_Damage_And_Die()
        {
            Vasya.GetDamage(Vasya.MaximumHealth);
            Assert.IsTrue(Vasya.IsDead);
        }

        [Test]
        public void Vasya_FullHP_Potion()
        {
            Vasya.UsePotion();
            Assert.AreEqual(Vasya.Health, Vasya.MaximumHealth);
        }

        [Test]
        public void Vasya_Get_1_damage_and_use_Potion()
        {
            Vasya.GetDamage(1);
            Vasya.UsePotion();
            Assert.AreEqual(Vasya.MaximumHealth, Vasya.Health);
        }

        [Test]
        public void Vasya_Heals()
        {
            Vasya.GetDamage(100);
            Vasya.UsePotion();
            int ExpectedHp = 140;
            int ActualHp = Vasya.Health;
            Assert.AreEqual(ExpectedHp, ActualHp);
        }

        [Test]
        public void Vasya_Can_Use_Potion_Twice()
        {
            Vasya.GetDamage(100);
            Vasya.UsePotion();
            Vasya.UsePotion();
            int ExpectedHp = 180;
            int ActualHp = Vasya.Health;
            Assert.AreEqual(ExpectedHp, ActualHp);
        }

        [Test]
        public void Vasya_Can_Use_Potion_Only_Twice()
        {
            Vasya.GetDamage(100);
            Vasya.UsePotion();
            Vasya.UsePotion();
            Vasya.UsePotion();
            Vasya.UsePotion();
            Vasya.UsePotion();
            int ExpectedHp = 180;
            int ActualHp = Vasya.Health;
            Assert.AreEqual(ExpectedHp, ActualHp);
        }

        [Test]
        public void Noob_Uses_Potion_And_Restore_1HP()
        {
            Noob.GetDamage(2);
            Noob.UsePotion();
            int ExpectedHp = 2;
            int ActualHp = Noob.Health;
            Assert.AreEqual(ExpectedHp, ActualHp);
        }

        [Test]
        public void Dead_Hero_Cant_Use_Potion()
        {
            Vasya.GetDamage(200);
            Vasya.UsePotion();
            int ExpectedHp = 0;
            int ActualHp = Vasya.Health;
            Assert.AreEqual(ExpectedHp, ActualHp);
        }

    }
}
